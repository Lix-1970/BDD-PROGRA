/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
public class VariablesRuta {
    
    private static String id_ruta;
    private static String origen;
    private static String destino;
    private static String distancia_km;
    private static String id_conductor;
    private static String id_vehiculo;

    public static String getId_ruta() {
        return id_ruta;
    }

    public static void setId_ruta(String id_ruta) {
        VariablesRuta.id_ruta = id_ruta;
    }

    public static String getOrigen() {
        return origen;
    }

    public static void setOrigen(String origen) {
        VariablesRuta.origen = origen;
    }

    public static String getDestino() {
        return destino;
    }

    public static void setDestino(String destino) {
        VariablesRuta.destino = destino;
    }

    public static String getDistancia_km() {
        return distancia_km;
    }

    public static void setDistancia_km(String distancia_km) {
        VariablesRuta.distancia_km = distancia_km;
    }

    public static String getId_conductor() {
        return id_conductor;
    }

    public static void setId_conductor(String id_conductor) {
        VariablesRuta.id_conductor = id_conductor;
    }

    public static String getId_vehiculo() {
        return id_vehiculo;
    }

    public static void setId_vehiculo(String id_vehiculo) {
        VariablesRuta.id_vehiculo = id_vehiculo;
    }
}
