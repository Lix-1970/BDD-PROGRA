/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
public class VariablesUsuario {
    
    private static String id_usuario;
    private static String nombre;
    private static String email;
    private static String contrasenia;
    private static String id_rol;
    private static String activo;

    public static String getId_usuario() {
        return id_usuario;
    }

    public static void setId_usuario(String id_usuario) {
        VariablesUsuario.id_usuario = id_usuario;
    }

    public static String getNombre() {
        return nombre;
    }

    public static void setNombre(String nombre) {
        VariablesUsuario.nombre = nombre;
    }

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        VariablesUsuario.email = email;
    }

    public static String getContrasenia() {
        return contrasenia;
    }

    public static void setContrasenia(String contrasenia) {
        VariablesUsuario.contrasenia = contrasenia;
    }

    public static String getId_rol() {
        return id_rol;
    }

    public static void setId_rol(String id_rol) {
        VariablesUsuario.id_rol = id_rol;
    }

    public static String getActivo() {
        return activo;
    }

    public static void setActivo(String activo) {
        VariablesUsuario.activo = activo;
    }
}
