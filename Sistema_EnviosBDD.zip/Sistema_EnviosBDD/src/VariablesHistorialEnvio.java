/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
public class VariablesHistorialEnvio {
    
    private static String id_historial;
    private static String id_envio;
    private static String id_estado;
    private static String id_usuario;
    private static String fecha_cambio;
    private static String comentario;

    public static String getId_historial() {
        return id_historial;
    }

    public static void setId_historial(String id_historial) {
        VariablesHistorialEnvio.id_historial = id_historial;
    }

    public static String getId_envio() {
        return id_envio;
    }

    public static void setId_envio(String id_envio) {
        VariablesHistorialEnvio.id_envio = id_envio;
    }

    public static String getId_estado() {
        return id_estado;
    }

    public static void setId_estado(String id_estado) {
        VariablesHistorialEnvio.id_estado = id_estado;
    }

    public static String getId_usuario() {
        return id_usuario;
    }

    public static void setId_usuario(String id_usuario) {
        VariablesHistorialEnvio.id_usuario = id_usuario;
    }

    public static String getFecha_cambio() {
        return fecha_cambio;
    }

    public static void setFecha_cambio(String fecha_cambio) {
        VariablesHistorialEnvio.fecha_cambio = fecha_cambio;
    }

    public static String getComentario() {
        return comentario;
    }

    public static void setComentario(String comentario) {
        VariablesHistorialEnvio.comentario = comentario;
    }
}
