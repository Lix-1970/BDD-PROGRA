/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author lissy
 */
public class crudEstadosEnvio {
    conexionsql con = new conexionsql();
    
    // --- INSERTAR ---
    public void InsertarEstadoEnvio(String estado, String descripcion_env){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "INSERT INTO estados_envio (estado, descripcion_env) "
                       + "VALUES ('" + estado + "', '" + descripcion_env + "')";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Estado de Envió Almacenado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar el estado de envío: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ACTUALIZAR ---
    public void ActualizarEstadoEnvio(String id_estado, String estado, String descripcion_env){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "UPDATE estados_envio SET estado='" + estado + "', descripcion_env='" + descripcion_env + "' "
                       + "WHERE id_estado=" + id_estado + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Estado de Envió Actualizado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar el estado de envío: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ELIMINAR ---
    public void EliminarEstadoEnvio(String id_estado){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "DELETE FROM estados_envio WHERE id_estado=" + id_estado + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Estado de Envió Eliminado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar el estado de envío: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- MOSTRAR / BUSCAR ---
    public void MostrarEstadoEnvio(String idBusqueda){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "SELECT * FROM estados_envio WHERE id_estado = " + idBusqueda + ";";
            
            ResultSet rs = st.executeQuery(sql);
            
            if (rs.next()) {
                VariablesEstadosEnvio.setId_estado(rs.getString("id_estado"));
                VariablesEstadosEnvio.setEstado(rs.getString("estado"));
                VariablesEstadosEnvio.setDescripcion_env(rs.getString("descripcion_env"));
            } else {
                VariablesEstadosEnvio.setId_estado("");
                VariablesEstadosEnvio.setEstado("");
                VariablesEstadosEnvio.setDescripcion_env("");
                JOptionPane.showMessageDialog(null, "No se encontró el estado de envío con ese ID.");
            }
            
            st.close();
            conexion.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el estado de envío: " + e.getMessage());
        }
    }
}
