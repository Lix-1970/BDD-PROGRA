package Vista;

import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class crudEnvios {
    conexionsql con = new conexionsql();

    // --- INSERTAR (incluye la llave primaria id_envio) ---
    public void InsertarEnvio(String id_envio, String cod_seguimiento, String id_cliente, String id_ruta,
            String id_estado, String peso, String dimensiones, String costo, String fecha_creacion){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "insert into envios (id_envio, cod_seguimiento, id_cliente, id_ruta, id_estado, "
                       + "peso, dimensiones, costo, fecha_creacion) "
                       + "values(" + id_envio + ", '" + cod_seguimiento + "', " + id_cliente + ", "
                       + id_ruta + ", " + id_estado + ", " + peso + ", '" + dimensiones + "', "
                       + costo + ", '" + fecha_creacion + "')";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Almacenados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- ACTUALIZAR ---
    public void ActualizarEnvio(String id_envio, String cod_seguimiento, String id_cliente, String id_ruta,
            String id_estado, String peso, String dimensiones, String costo, String fecha_creacion){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "update envios set cod_seguimiento='" + cod_seguimiento + "', id_cliente=" + id_cliente + ", "
                       + "id_ruta=" + id_ruta + ", id_estado=" + id_estado + ", peso=" + peso + ", "
                       + "dimensiones='" + dimensiones + "', costo=" + costo + ", "
                       + "fecha_creacion='" + fecha_creacion + "' "
                       + "where id_envio=" + id_envio + "; ";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Actualizados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- ELIMINAR ---
    public void EliminarEnvio(String id_envio){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "delete from envios where id_envio=" + id_envio + "; ";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Eliminados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- MOSTRAR / BUSCAR ---
    public void MostrarEnvio(String id_envio){
        VariablesEnvio var = new VariablesEnvio();

        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            // costo es de tipo money: se convierte a numeric para que salga como 25.50
            // y no como "25,50 €" o "$25.50" (depende de la configuración regional)
            String sql = "select id_envio, cod_seguimiento, id_cliente, id_ruta, id_estado, "
                       + "peso, dimensiones, costo::numeric as costo, fecha_creacion "
                       + "from envios where id_envio=" + id_envio + "; ";

            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                var.setId_envio(rs.getString("id_envio"));
                var.setCod_seguimiento(rs.getString("cod_seguimiento"));
                var.setId_cliente(rs.getString("id_cliente"));
                var.setId_ruta(rs.getString("id_ruta"));
                var.setId_estado(rs.getString("id_estado"));
                var.setPeso(rs.getString("peso"));
                var.setDimensiones(rs.getString("dimensiones"));
                var.setCosto(rs.getString("costo"));
                var.setFecha_creacion(rs.getString("fecha_creacion"));
            }else{
                var.setId_envio("");
                var.setCod_seguimiento("");
                var.setId_cliente("");
                var.setId_ruta("");
                var.setId_estado("");
                var.setPeso("");
                var.setDimensiones("");
                var.setCosto("");
                var.setFecha_creacion("");
                JOptionPane.showMessageDialog(null, "No se encontró el registro!!!");
            }
            st.close();
            conexion.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
}