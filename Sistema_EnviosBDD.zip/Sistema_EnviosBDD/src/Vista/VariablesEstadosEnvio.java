package Vista;

public class VariablesEstadosEnvio {

    private static String id_estado;
    private static String estado;
    private static String descripcion_envio;

    public String getId_estado() { return id_estado; }
    public void setId_estado(String id_estado) { this.id_estado = id_estado; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getDescripcion_envio() { return descripcion_envio; }
    public void setDescripcion_envio(String descripcion_envio) { this.descripcion_envio = descripcion_envio; }
}