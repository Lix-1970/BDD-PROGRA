package Vista;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
/**
 *
 * @author lissy
 */
public class crudConductor {
    conexionsql con = new conexionsql();
    
    // --- INSERTAR (Actualizado para incluir el id_conductor) ---
    public void InsertarConductor(String id_conductor, String nombre, String licencia, String telefono, String disponible){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "INSERT INTO conductores (id_conductor, nombre, licencia, telefono, disponible) "
                       + "VALUES (" + id_conductor + ", '" + nombre + "', '" + licencia + "', '" + telefono + "', " + disponible + ")";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Conductor Almacenado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ACTUALIZAR ---
    public void ActualizarConductor(String id_conductor, String nombre, String licencia, String telefono, String disponible){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "UPDATE conductores SET nombre='" + nombre + "', licencia='" + licencia + "', "
                       + "telefono='" + telefono + "', disponible=" + disponible + " "
                       + "WHERE id_conductor=" + id_conductor + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Conductor Actualizado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ELIMINAR ---
    public void EliminarConductor(String id_conductor){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "DELETE FROM conductores WHERE id_conductor=" + id_conductor + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Conductor Eliminado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- MOSTRAR / BUSCAR ---
    public void MostrarConductor(String idBusqueda){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "SELECT * FROM conductores WHERE id_conductor = " + idBusqueda + ";";
            
            ResultSet rs = st.executeQuery(sql);
            
            if (rs.next()) {
                VariablesConductor.setId_conductor(rs.getString("id_conductor"));
                VariablesConductor.setNombre(rs.getString("nombre"));
                VariablesConductor.setLicencia(rs.getString("licencia"));
                VariablesConductor.setTelefono(rs.getString("telefono"));
                VariablesConductor.setDisponible(rs.getString("disponible"));
            } else {
                VariablesConductor.setId_conductor("");
                VariablesConductor.setNombre("");
                VariablesConductor.setLicencia("");
                VariablesConductor.setTelefono("");
                VariablesConductor.setDisponible("");
                JOptionPane.showMessageDialog(null, "No se encontró el conductor con ese ID.");
            }
            
            st.close();
            conexion.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el conductor: " + e.getMessage());
        }
    }
}