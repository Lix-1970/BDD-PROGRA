package Vista;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
public class VariablesConductor {
    
    private static String id_conductor;
    private static String nombre;
    private static String licencia;
    private static String telefono;
    private static String disponible;

    public static String getId_conductor() {
        return id_conductor;
    }

    public static void setId_conductor(String id_conductor) {
        VariablesConductor.id_conductor = id_conductor;
    }

    public static String getNombre() {
        return nombre;
    }

    public static void setNombre(String nombre) {
        VariablesConductor.nombre = nombre;
    }

    public static String getLicencia() {
        return licencia;
    }

    public static void setLicencia(String licencia) {
        VariablesConductor.licencia = licencia;
    }

    public static String getTelefono() {
        return telefono;
    }

    public static void setTelefono(String telefono) {
        VariablesConductor.telefono = telefono;
    }

    public static String getDisponible() {
        return disponible;
    }

    public static void setDisponible(String disponible) {
        VariablesConductor.disponible = disponible;
    }
}
