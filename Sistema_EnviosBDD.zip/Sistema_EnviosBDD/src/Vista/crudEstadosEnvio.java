package Vista;

import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class crudEstadosEnvio {
    conexionsql con = new conexionsql();

    // --- INSERTAR (incluye la llave primaria id_estado) ---
    public void InsertarEstadoEnvio(String id_estado, String estado, String descripcion_envio){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "insert into estados_envio (id_estado, estado, descripcion_envio) "
                       + "values(" + id_estado + ", '" + estado + "', '" + descripcion_envio + "')";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Almacenados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- ACTUALIZAR ---
    public void ActualizarEstadoEnvio(String id_estado, String estado, String descripcion_envio){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "update estados_envio set estado='" + estado + "', "
                       + "descripcion_envio='" + descripcion_envio + "' "
                       + "where id_estado=" + id_estado + "; ";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Actualizados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- ELIMINAR ---
    public void EliminarEstadoEnvio(String id_estado){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "delete from estados_envio where id_estado=" + id_estado + "; ";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Eliminados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- MOSTRAR / BUSCAR ---
    public void MostrarEstadoEnvio(String id_estado){
        VariablesEstadosEnvio var = new VariablesEstadosEnvio();

        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "select * from estados_envio "
                       + "where id_estado=" + id_estado + "; ";

            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                var.setId_estado(rs.getString("id_estado"));
                var.setEstado(rs.getString("estado"));
                var.setDescripcion_envio(rs.getString("descripcion_envio"));
            }else{
                var.setId_estado("");
                var.setEstado("");
                var.setDescripcion_envio("");
                JOptionPane.showMessageDialog(null, "No se encontró el registro!!!");
            }
            st.close();
            conexion.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
}