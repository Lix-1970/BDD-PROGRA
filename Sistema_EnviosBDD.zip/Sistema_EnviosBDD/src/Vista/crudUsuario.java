package Vista;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author lissy
 */
public class crudUsuario {
    conexionsql con = new conexionsql();
    
    // --- VALIDAR LOGIN ---
    public void ValidarLogin(String usuario, String contrasenia) {
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "SELECT * FROM usuarios WHERE nombre = '" + usuario + "' AND contrasenia = '" + contrasenia + "';";
            
            ResultSet rs = st.executeQuery(sql);
            
            if (rs.next()) {
                VariablesUsuario.setId_usuario(rs.getString("id_usuario"));
                VariablesUsuario.setNombre(rs.getString("nombre"));
                VariablesUsuario.setEmail(rs.getString("email"));
                VariablesUsuario.setContrasenia(rs.getString("contrasenia"));
                VariablesUsuario.setId_rol(rs.getString("id_rol"));
                VariablesUsuario.setActivo(rs.getString("activo"));
            } else {
                VariablesUsuario.setId_usuario("");
                VariablesUsuario.setNombre("");
                VariablesUsuario.setEmail("");
                VariablesUsuario.setContrasenia("");
                VariablesUsuario.setId_rol("");
                VariablesUsuario.setActivo("");
            }
            
            st.close();
            conexion.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al validar el login: " + e.getMessage());
        }
    }
    
    // --- INSERTAR ---
    public void InsertarUsuario(String nombre, String email, String contrasenia, String id_rol, String activo){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "INSERT INTO usuarios (nombre, email, contrasenia, id_rol, activo) "
                       + "VALUES ('" + nombre + "', '" + email + "', '" + contrasenia + "', " + id_rol + ", " + activo + ")";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Usuario Almacenado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar el usuario: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ACTUALIZAR ---
    public void ActualizarUsuario(String id_usuario, String nombre, String email, String contrasenia, String id_rol, String activo){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "UPDATE usuarios SET nombre='" + nombre + "', email='" + email + "', "
                       + "contrasenia='" + contrasenia + "', id_rol=" + id_rol + ", activo=" + activo + " "
                       + "WHERE id_usuario=" + id_usuario + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Usuario Actualizado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar el usuario: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ELIMINAR ---
    public void EliminarUsuario(String id_usuario){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "DELETE FROM usuarios WHERE id_usuario=" + id_usuario + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Usuario Eliminado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar el usuario: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- MOSTRAR / BUSCAR ---
    public void MostrarUsuario(String idBusqueda){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "SELECT * FROM usuarios WHERE id_usuario = " + idBusqueda + ";";
            
            ResultSet rs = st.executeQuery(sql);
            
            if (rs.next()) {
                VariablesUsuario.setId_usuario(rs.getString("id_usuario"));
                VariablesUsuario.setNombre(rs.getString("nombre"));
                VariablesUsuario.setEmail(rs.getString("email"));
                VariablesUsuario.setContrasenia(rs.getString("contrasenia"));
                VariablesUsuario.setId_rol(rs.getString("id_rol"));
                VariablesUsuario.setActivo(rs.getString("activo"));
            } else {
                VariablesUsuario.setId_usuario("");
                VariablesUsuario.setNombre("");
                VariablesUsuario.setEmail("");
                VariablesUsuario.setContrasenia("");
                VariablesUsuario.setId_rol("");
                VariablesUsuario.setActivo("");
                JOptionPane.showMessageDialog(null, "No se encontró el usuario con ese ID.");
            }
            
            st.close();
            conexion.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el usuario: " + e.getMessage());
        }
    }
}
