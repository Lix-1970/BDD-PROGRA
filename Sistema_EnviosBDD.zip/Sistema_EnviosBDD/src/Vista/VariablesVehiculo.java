package Vista;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
public class VariablesVehiculo {
    
    private static String id_vehiculo;
    private static String placa;
    private static String modelo;
    private static String capacidad_peso;
    private static String disponible;

    public static String getId_vehiculo() {
        return id_vehiculo;
    }

    public static void setId_vehiculo(String id_vehiculo) {
        VariablesVehiculo.id_vehiculo = id_vehiculo;
    }

    public static String getPlaca() {
        return placa;
    }

    public static void setPlaca(String placa) {
        VariablesVehiculo.placa = placa;
    }

    public static String getModelo() {
        return modelo;
    }

    public static void setModelo(String modelo) {
        VariablesVehiculo.modelo = modelo;
    }

    public static String getCapacidad_peso() {
        return capacidad_peso;
    }

    public static void setCapacidad_peso(String capacidad_peso) {
        VariablesVehiculo.capacidad_peso = capacidad_peso;
    }

    public static String getDisponible() {
        return disponible;
    }

    public static void setDisponible(String disponible) {
        VariablesVehiculo.disponible = disponible;
    }
}