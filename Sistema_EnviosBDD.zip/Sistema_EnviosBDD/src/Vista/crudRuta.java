package Vista;

import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class crudRuta {
    conexionsql con = new conexionsql();
    
    // --- INSERTAR (Ahora incluye el id_ruta igual que el ejemplo del ingeniero) ---
    public void InsertarRuta(String id_ruta, String id_conductor, String id_vehiculo, String origen, String destino, String distancia_km){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "INSERT INTO rutas (id_ruta, id_conductor, id_vehiculo, origen, destino, distancia_km) "
                       + "VALUES (" + id_ruta + ", " + id_conductor + ", " + id_vehiculo + ", '" + origen + "', '" + destino + "', " + distancia_km + ")";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Ruta Almacenada Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar la ruta: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ACTUALIZAR ---
    public void ActualizarRuta(String id_ruta, String origen, String destino, String distancia_km, String id_conductor, String id_vehiculo){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "UPDATE rutas SET origen='" + origen + "', destino='" + destino + "', "
                       + "distancia_km=" + distancia_km + ", id_conductor=" + id_conductor + ", id_vehiculo=" + id_vehiculo + " "
                       + "WHERE id_ruta=" + id_ruta + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Ruta Actualizada Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar la ruta: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ELIMINAR ---
    public void EliminarRuta(String id_ruta){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "DELETE FROM rutas WHERE id_ruta=" + id_ruta + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Ruta Eliminada Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar la ruta: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- MOSTRAR / BUSCAR ---
    public void MostrarRuta(String idBusqueda){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "SELECT * FROM rutas WHERE id_ruta = " + idBusqueda + ";";
            
            ResultSet rs = st.executeQuery(sql);
            
            if (rs.next()) {
                VariablesRuta.setId_ruta(rs.getString("id_ruta"));
                VariablesRuta.setOrigen(rs.getString("origen"));
                VariablesRuta.setDestino(rs.getString("destino"));
                VariablesRuta.setDistancia_km(rs.getString("distancia_km"));
                VariablesRuta.setId_conductor(rs.getString("id_conductor"));
                VariablesRuta.setId_vehiculo(rs.getString("id_vehiculo"));
            } else {
                VariablesRuta.setId_ruta("");
                VariablesRuta.setOrigen("");
                VariablesRuta.setDestino("");
                VariablesRuta.setDistancia_km("");
                VariablesRuta.setId_conductor("");
                VariablesRuta.setId_vehiculo("");
                JOptionPane.showMessageDialog(null, "No se encontró el registro!!!");
            }
            
            st.close();
            conexion.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar la ruta: " + e.getMessage());
        }
    }
}