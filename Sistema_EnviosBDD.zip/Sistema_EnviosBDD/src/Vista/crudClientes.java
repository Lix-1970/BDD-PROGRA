package Vista;

import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class crudClientes {
    conexionsql con = new conexionsql();

    // --- INSERTAR (incluye la llave primaria id_cliente) ---
    public void InsertarCliente(String id_cliente, String nombre, String telefono, String email, String direccion){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "insert into clientes (id_cliente, nombre, telefono, email, direccion) "
                       + "values(" + id_cliente + ", '" + nombre + "', '" + telefono + "', '"
                       + email + "', '" + direccion + "')";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Almacenados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- ACTUALIZAR ---
    public void ActualizarCliente(String id_cliente, String nombre, String telefono, String email, String direccion){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "update clientes set nombre='" + nombre + "', telefono='" + telefono + "', "
                       + "email='" + email + "', direccion='" + direccion + "' "
                       + "where id_cliente=" + id_cliente + "; ";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Actualizados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- ELIMINAR ---
    public void EliminarCliente(String id_cliente){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "delete from clientes where id_cliente=" + id_cliente + "; ";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "Datos Eliminados Correctamente!!!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- MOSTRAR / BUSCAR ---
    public void MostrarCliente(String id_cliente){
        VariablesCliente var = new VariablesCliente();

        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();

            String sql = "select * from clientes "
                       + "where id_cliente=" + id_cliente + "; ";

            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                var.setId_cliente(rs.getString("id_cliente"));
                var.setNombre(rs.getString("nombre"));
                var.setTelefono(rs.getString("telefono"));
                var.setEmail(rs.getString("email"));
                var.setDireccion(rs.getString("direccion"));
            }else{
                var.setId_cliente("");
                var.setNombre("");
                var.setTelefono("");
                var.setEmail("");
                var.setDireccion("");
                JOptionPane.showMessageDialog(null, "No se encontró el registro!!!");
            }
            st.close();
            conexion.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar!!!! " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
}