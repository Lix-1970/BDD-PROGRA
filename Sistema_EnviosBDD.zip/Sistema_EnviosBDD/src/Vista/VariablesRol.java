package Vista;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
public class VariablesRol {
    
    private static String id_rol;
    private static String nombre;
    private static String descri_rol;

    public static String getId_rol() {
        return id_rol;
    }

    public static void setId_rol(String id_rol) {
        VariablesRol.id_rol = id_rol;
    }

    public static String getNombre() {
        return nombre;
    }

    public static void setNombre(String nombre) {
        VariablesRol.nombre = nombre;
    }

    public static String getDescri_rol() {
        return descri_rol;
    }

    public static void setDescri_rol(String descri_rol) {
        VariablesRol.descri_rol = descri_rol;
    }
}
