/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author lissy
 */
public class crudHistorialEnvio {
    conexionsql con = new conexionsql();
    
    // --- INSERTAR ---
    public void InsertarHistorialEnvio(String id_envio, String id_estado, String id_usuario, String fecha_cambio, String comentario){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "INSERT INTO historial_envio (id_envio, id_estado, id_usuario, fecha_cambio, comentario) "
                       + "VALUES (" + id_envio + ", " + id_estado + ", " + id_usuario + ", '" + fecha_cambio + "', '" + comentario + "')";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Historial de Envíos Almacenado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar el historial: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ACTUALIZAR ---
    public void ActualizarHistorialEnvio(String id_historial, String id_envio, String id_estado, String id_usuario, String fecha_cambio, String comentario){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "UPDATE historial_envio SET id_envio=" + id_envio + ", id_estado=" + id_estado + ", "
                       + "id_usuario=" + id_usuario + ", fecha_cambio='" + fecha_cambio + "', comentario='" + comentario + "' "
                       + "WHERE id_historial=" + id_historial + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Historial de Envíos Actualizado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar el historial: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ELIMINAR ---
    public void EliminarHistorialEnvio(String id_historial){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "DELETE FROM historial_envio WHERE id_historial=" + id_historial + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Historial de Envíos Eliminado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar el historial: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- MOSTRAR / BUSCAR ---
    public void MostrarHistorialEnvio(String idBusqueda){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "SELECT * FROM historial_envio WHERE id_historial = " + idBusqueda + ";";
            
            ResultSet rs = st.executeQuery(sql);
            
            if (rs.next()) {
                VariablesHistorialEnvio.setId_historial(rs.getString("id_historial"));
                VariablesHistorialEnvio.setId_envio(rs.getString("id_envio"));
                VariablesHistorialEnvio.setId_estado(rs.getString("id_estado"));
                VariablesHistorialEnvio.setId_usuario(rs.getString("id_usuario"));
                VariablesHistorialEnvio.setFecha_cambio(rs.getString("fecha_cambio"));
                VariablesHistorialEnvio.setComentario(rs.getString("comentario"));
            } else {
                VariablesHistorialEnvio.setId_historial("");
                VariablesHistorialEnvio.setId_envio("");
                VariablesHistorialEnvio.setId_estado("");
                VariablesHistorialEnvio.setId_usuario("");
                VariablesHistorialEnvio.setFecha_cambio("");
                VariablesHistorialEnvio.setComentario("");
                JOptionPane.showMessageDialog(null, "No se encontró el registro de historial con ese ID.");
            }
            
            st.close();
            conexion.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el historial: " + e.getMessage());
        }
    }
}
