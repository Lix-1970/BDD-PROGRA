/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
public class VariablesEnvio {
    
    private static String id_envio;
    private static String cod_seguimiento;
    private static String id_cliente;
    private static String id_ruta;
    private static String id_estado;
    private static String peso;
    private static String dimensiones;
    private static String costo;
    private static String fecha_creacion;

    public static String getId_envio() {
        return id_envio;
    }

    public static void setId_envio(String id_envio) {
        VariablesEnvio.id_envio = id_envio;
    }

    public static String getCod_seguimiento() {
        return cod_seguimiento;
    }

    public static void setCod_seguimiento(String cod_seguimiento) {
        VariablesEnvio.cod_seguimiento = cod_seguimiento;
    }

    public static String getId_cliente() {
        return id_cliente;
    }

    public static void setId_cliente(String id_cliente) {
        VariablesEnvio.id_cliente = id_cliente;
    }

    public static String getId_ruta() {
        return id_ruta;
    }

    public static void setId_ruta(String id_ruta) {
        VariablesEnvio.id_ruta = id_ruta;
    }

    public static String getId_estado() {
        return id_estado;
    }

    public static void setId_estado(String id_estado) {
        VariablesEnvio.id_estado = id_estado;
    }

    public static String getPeso() {
        return peso;
    }

    public static void setPeso(String peso) {
        VariablesEnvio.peso = peso;
    }

    public static String getDimensiones() {
        return dimensiones;
    }

    public static void setDimensiones(String dimensiones) {
        VariablesEnvio.dimensiones = dimensiones;
    }

    public static String getCosto() {
        return costo;
    }

    public static void setCosto(String costo) {
        VariablesEnvio.costo = costo;
    }

    public static String getFecha_creacion() {
        return fecha_creacion;
    }

    public static void setFecha_creacion(String fecha_creacion) {
        VariablesEnvio.fecha_creacion = fecha_creacion;
    }
}
