/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lissy
 */
public class VariablesEstadosEnvio {
    
    private static String id_estado;
    private static String estado;
    private static String descripcion_env;

    public static String getId_estado() {
        return id_estado;
    }

    public static void setId_estado(String id_estado) {
        VariablesEstadosEnvio.id_estado = id_estado;
    }

    public static String getEstado() {
        return estado;
    }

    public static void setEstado(String estado) {
        VariablesEstadosEnvio.estado = estado;
    }

    public static String getDescripcion_env() {
        return descripcion_env;
    }

    public static void setDescripcion_env(String descripcion_env) {
        VariablesEstadosEnvio.descripcion_env = descripcion_env;
    }
}
