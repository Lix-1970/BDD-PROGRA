/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author lissy
 */
public class crudVehiculos {
    conexionsql con = new conexionsql();
    
    // --- INSERTAR ---
    public void InsertarVehiculo(String placa, String modelo, String capacidad_peso, String disponible){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "INSERT INTO vehiculos (placa, modelo, capacidad_peso, disponible) "
                       + "VALUES ('" + placa + "', '" + modelo + "', " + capacidad_peso + ", " + disponible + ")";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Vehículo Almacenado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar el vehículo: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ACTUALIZAR ---
    public void ActualizarVehiculo(String id_vehiculo, String placa, String modelo, String capacidad_peso, String disponible){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "UPDATE vehiculos SET placa='" + placa + "', modelo='" + modelo + "', "
                       + "capacidad_peso=" + capacidad_peso + ", disponible=" + disponible + " "
                       + "WHERE id_vehiculo=" + id_vehiculo + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Vehículo Actualizado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar el vehículo: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ELIMINAR ---
    public void EliminarVehiculo(String id_vehiculo){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "DELETE FROM vehiculos WHERE id_vehiculo=" + id_vehiculo + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Vehículo Eliminado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar el vehículo: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- MOSTRAR / BUSCAR ---
    public void MostrarVehiculo(String idBusqueda){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "SELECT * FROM vehiculos WHERE id_vehiculo = " + idBusqueda + ";";
            
            ResultSet rs = st.executeQuery(sql);
            
            if (rs.next()) {
                VariablesVehiculo.setId_vehiculo(rs.getString("id_vehiculo"));
                VariablesVehiculo.setPlaca(rs.getString("placa"));
                VariablesVehiculo.setModelo(rs.getString("modelo"));
                VariablesVehiculo.setCapacidad_peso(rs.getString("capacidad_peso"));
                VariablesVehiculo.setDisponible(rs.getString("disponible"));
            } else {
                VariablesVehiculo.setId_vehiculo("");
                VariablesVehiculo.setPlaca("");
                VariablesVehiculo.setModelo("");
                VariablesVehiculo.setCapacidad_peso("");
                VariablesVehiculo.setDisponible("");
                JOptionPane.showMessageDialog(null, "No se encontró el vehículo con ese ID.");
            }
            
            st.close();
            conexion.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el vehículo: " + e.getMessage());
        }
    }
}
