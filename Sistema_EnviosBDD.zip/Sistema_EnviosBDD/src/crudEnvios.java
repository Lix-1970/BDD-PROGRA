/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author lissy
 */
public class crudEnvios {
    conexionsql con = new conexionsql();
    
    // --- INSERTAR ---
    public void InsertarEnvio(String cod_seguimiento, String id_cliente, String id_ruta, String id_estado, String peso, String dimensiones, String costo, String fecha_creacion){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "INSERT INTO envios (cod_seguimiento, id_cliente, id_ruta, id_estado, peso, dimensiones, costo, fecha_creacion) "
                       + "VALUES ('" + cod_seguimiento + "', " + id_cliente + ", " + id_ruta + ", " + id_estado + ", " + peso + ", '" + dimensiones + "', " + costo + ", '" + fecha_creacion + "')";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Envío Almacenado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo guardar el envío: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ACTUALIZAR ---
    public void ActualizarEnvio(String id_envio, String cod_seguimiento, String id_cliente, String id_ruta, String id_estado, String peso, String dimensiones, String costo, String fecha_creacion){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "UPDATE envios SET cod_seguimiento='" + cod_seguimiento + "', id_cliente=" + id_cliente + ", "
                       + "id_ruta=" + id_ruta + ", id_estado=" + id_estado + ", peso=" + peso + ", "
                       + "dimensiones='" + dimensiones + "', costo=" + costo + ", fecha_creacion='" + fecha_creacion + "' "
                       + "WHERE id_envio=" + id_envio + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Envío Actualizado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Actualizar el envío: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- ELIMINAR ---
    public void EliminarEnvio(String id_envio){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "DELETE FROM envios WHERE id_envio=" + id_envio + ";";
            
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "¡Envío Eliminado Correctamente!", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Eliminar el envío: " + e.getMessage(),
                    "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- MOSTRAR / BUSCAR ---
    public void MostrarEnvio(String idBusqueda){
        try {
            Connection conexion = con.conectar();
            java.sql.Statement st = conexion.createStatement();
            
            String sql = "SELECT * FROM envios WHERE id_envio = " + idBusqueda + ";";
            
            ResultSet rs = st.executeQuery(sql);
            
            if (rs.next()) {
                VariablesEnvio.setId_envio(rs.getString("id_envio"));
                VariablesEnvio.setCod_seguimiento(rs.getString("cod_seguimiento"));
                VariablesEnvio.setId_cliente(rs.getString("id_cliente"));
                VariablesEnvio.setId_ruta(rs.getString("id_ruta"));
                VariablesEnvio.setId_estado(rs.getString("id_estado"));
                VariablesEnvio.setPeso(rs.getString("peso"));
                VariablesEnvio.setDimensiones(rs.getString("dimensiones"));
                VariablesEnvio.setCosto(rs.getString("costo"));
                VariablesEnvio.setFecha_creacion(rs.getString("fecha_creacion"));
            } else {
                VariablesEnvio.setId_envio("");
                VariablesEnvio.setCod_seguimiento("");
                VariablesEnvio.setId_cliente("");
                VariablesEnvio.setId_ruta("");
                VariablesEnvio.setId_estado("");
                VariablesEnvio.setPeso("");
                VariablesEnvio.setDimensiones("");
                VariablesEnvio.setCosto("");
                VariablesEnvio.setFecha_creacion("");
                JOptionPane.showMessageDialog(null, "No se encontró el envío con ese ID.");
            }
            
            st.close();
            conexion.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el envío: " + e.getMessage());
        }
    }
}